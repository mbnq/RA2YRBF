; ######  ######  #     # ####### #######    ####### ####### ######   #####  #######    
; #     # #     # #     #    #    #          #       #     # #     # #     # #          
; #     # #     # #     #    #    #          #       #     # #     # #       #          
; ######  ######  #     #    #    #####      #####   #     # ######  #       #####      
; #     # #   #   #     #    #    #          #       #     # #   #   #       #          
; #     # #    #  #     #    #    #          #       #     # #    #  #     # #          
; ######  #     #  #####     #    #######    #       ####### #     #  #####  #######    
;
;
;                  
; #####  #   #    #    # #####  #    #  ####  
; #    #  # #     ##  ## #    # ##   # #    # 
; #####    #      # ## # #####  # #  # #    # 
; #    #   #      #    # #    # #  # # #  # # 
; #    #   #      #    # #    # #   ## #   #  
; #####    #      #    # #####  #    #  ### # 
;
;
; 
; mbnq00@gmail.com
;
; .ini 	Version: 0.6.50
;  mod	Version: 0.6.50
;_____________________________________________________________________________________


BFConsole.exe
	Originally created to work with Ares but should work with any .log file.
	Simply drag and drop logfile to start monitoring it realtime in console window.
	You can also run it from console, syntax is very simple:
		BFConsole.exe anyname.log

	With the new 0.6.50 mod launcher it can start auto if you put BFConsole.exe to
		\Command and Conquer Red Alert II\debug\
	Then just start the game with BF_Launcher.exe
	
mbnq.pl 2024