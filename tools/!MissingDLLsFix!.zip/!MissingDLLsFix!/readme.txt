; ######  ######  #     # ####### #######    ####### ####### ######   #####  #######    
; #     # #     # #     #    #    #          #       #     # #     # #     # #          
; #     # #     # #     #    #    #          #       #     # #     # #       #          
; ######  ######  #     #    #    #####      #####   #     # ######  #       #####      
; #     # #   #   #     #    #    #          #       #     # #   #   #       #          
; #     # #    #  #     #    #    #          #       #     # #    #  #     # #          
; ######  #     #  #####     #    #######    #       ####### #     #  #####  #######    
;
;
;                  
; #####  #   #    #    # #####  #    #  ####  
; #    #  # #     ##  ## #    # ##   # #    # 
; #####    #      # ## # #####  # #  # #    # 
; #    #   #      #    # #    # #  # # #  # # 
; #    #   #      #    # #    # #   ## #   #  
; #####    #      #    # #####  #    #  ### # 
;
;
; 
; mbnq00@gmail.com
;
; .ini 	Version: 0.7.47
;  mod	Version: 0.7.47
;_____________________________________________________________________________________


MissingDLLsFix
	If you having problems running tools like, bf_launcher, mapbrutelizer, bfconsole
	you may need to install latest Microsoft Visual C++ Redistributable packages.
	You can get them here:
	
	https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170
	
	Make sure to install both x86 and x64 versions.
	
	You can also try copying .dll files from \dll\ folder to same location BF_LAUNCHER.EXE is at.

mbnq.pl 2024