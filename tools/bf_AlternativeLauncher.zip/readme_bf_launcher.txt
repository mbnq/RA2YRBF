; ######  ######  #     # ####### #######    ####### ####### ######   #####  #######    
; #     # #     # #     #    #    #          #       #     # #     # #     # #          
; #     # #     # #     #    #    #          #       #     # #     # #       #          
; ######  ######  #     #    #    #####      #####   #     # ######  #       #####      
; #     # #   #   #     #    #    #          #       #     # #   #   #       #          
; #     # #    #  #     #    #    #          #       #     # #    #  #     # #          
; ######  #     #  #####     #    #######    #       ####### #     #  #####  #######    
;
;
;                  
; #####  #   #    #    # #####  #    #  ####  
; #    #  # #     ##  ## #    # ##   # #    # 
; #####    #      # ## # #####  # #  # #    # 
; #    #   #      #    # #    # #  # # #  # # 
; #    #   #      #    # #    # #   ## #   #  
; #####    #      #    # #####  #    #  ### # 
;
;
; 
; mbnq00@gmail.com
;
; .ini 	Version: 0.6.50
;  mod	Version: 0.6.50
;_____________________________________________________________________________________


bf_launcher.bat
	You can use this script to launch Brute Force if you are afraid of running .exe files. 
	However, it does not utilize more than one CPU core at the moment. It will work fine, 
	just without the benefits of spreading the load across multiple cores.
	
	Put bf_launcher.bat in
		\Command and Conquer Red Alert II\
	Then just doubleclick bf_launcher.bat
	
mbnq.pl 2024