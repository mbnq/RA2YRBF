; ######  ######  #     # ####### #######    ####### ####### ######   #####  #######    
; #     # #     # #     #    #    #          #       #     # #     # #     # #          
; #     # #     # #     #    #    #          #       #     # #     # #       #          
; ######  ######  #     #    #    #####      #####   #     # ######  #       #####      
; #     # #   #   #     #    #    #          #       #     # #   #   #       #          
; #     # #    #  #     #    #    #          #       #     # #    #  #     # #          
; ######  #     #  #####     #    #######    #       ####### #     #  #####  #######    
;
;
;                  
; #####  #   #    #    # #####  #    #  ####  
; #    #  # #     ##  ## #    # ##   # #    # 
; #####    #      # ## # #####  # #  # #    # 
; #    #   #      #    # #    # #  # # #  # # 
; #    #   #      #    # #    # #   ## #   #  
; #####    #      #    # #####  #    #  ### # 
;
;
; 
; mbnq00@gmail.com
;
; .ini 	Version: 0.6.50
;  mod	Version: 0.6.50
;_____________________________________________________________________________________


bf_launcher.bat
	You can use this script to launch Brute Force if you are affraid of running .exe files.
	
	Put bf_launcher.bat in
		\Command and Conquer Red Alert II\
	Then just doubleclick bf_launcher.bat
	
mbnq.pl 2024