copy RA2MD.INI into your game directory
(folder with YURI.exe)