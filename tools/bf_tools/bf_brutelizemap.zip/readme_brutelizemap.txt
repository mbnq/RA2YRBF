; ######  ######  #     # ####### #######    ####### ####### ######   #####  #######    
; #     # #     # #     #    #    #          #       #     # #     # #     # #          
; #     # #     # #     #    #    #          #       #     # #     # #       #          
; ######  ######  #     #    #    #####      #####   #     # ######  #       #####      
; #     # #   #   #     #    #    #          #       #     # #   #   #       #          
; #     # #    #  #     #    #    #          #       #     # #    #  #     # #          
; ######  #     #  #####     #    #######    #       ####### #     #  #####  #######    
;
;
;                  
; #####  #   #    #    # #####  #    #  ####  
; #    #  # #     ##  ## #    # ##   # #    # 
; #####    #      # ## # #####  # #  # #    # 
; #    #   #      #    # #    # #  # # #  # # 
; #    #   #      #    # #    # #   ## #   #  
; #####    #      #    # #####  #    #  ### # 
;
;
; 
; mbnq00@gmail.com
;
; .ini 	Version: 0.6.50
;  mod	Version: 0.6.50
;_____________________________________________________________________________________


brutelizemap.exe
	Simply drag and drop mapfile onto brutelizemap.exe to patch it.
	Patching adds spawning random crates for all players on their starting positions.
	It also makes bridges very strong to some sorf of 
	prevent AI from not being able to fix it.
		
	This is more sofisticated than BF map patcher, it removes original trigger settings
	first, then does it's magic. It also checks for previous bridge settings first.
			
	You can also find usage info by just running the program.
	Program will be opensource on my github profile.
	
	It should work with other mods and vanilla RA2YR aswell.

mbnq.pl 2024