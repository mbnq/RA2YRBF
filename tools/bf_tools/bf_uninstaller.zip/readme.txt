; ######  ######  #     # ####### #######    ####### ####### ######   #####  #######    
; #     # #     # #     #    #    #          #       #     # #     # #     # #          
; #     # #     # #     #    #    #          #       #     # #     # #       #          
; ######  ######  #     #    #    #####      #####   #     # ######  #       #####      
; #     # #   #   #     #    #    #          #       #     # #   #   #       #          
; #     # #    #  #     #    #    #          #       #     # #    #  #     # #          
; ######  #     #  #####     #    #######    #       ####### #     #  #####  #######    
;
;
;                  
; #####  #   #    #    # #####  #    #  ####  
; #    #  # #     ##  ## #    # ##   # #    # 
; #####    #      # ## # #####  # #  # #    # 
; #    #   #      #    # #    # #  # # #  # # 
; #    #   #      #    # #    # #   ## #   #  
; #####    #      #    # #####  #    #  ### # 
;
;
; 
; mbnq00@gmail.com
;
; .ini 	Version: 0.8.21
;  mod	Version: 0.8.21
;
; Reworked for CnCnet client based BF version
;_____________________________________________________________________________________


Uninstaller
	Unzip and put bf_uninstaller in the folder where you installed the mod, then run it.
	Remove bf_uninstaller.bat manually after use.

mbnq.pl 2024