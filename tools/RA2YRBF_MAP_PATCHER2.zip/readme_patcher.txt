; ######  ######  #     # ####### #######    ####### ####### ######   #####  #######    
; #     # #     # #     #    #    #          #       #     # #     # #     # #          
; #     # #     # #     #    #    #          #       #     # #     # #       #          
; ######  ######  #     #    #    #####      #####   #     # ######  #       #####      
; #     # #   #   #     #    #    #          #       #     # #   #   #       #          
; #     # #    #  #     #    #    #          #       #     # #    #  #     # #          
; ######  #     #  #####     #    #######    #       ####### #     #  #####  #######    
;
;
;                  
; #####  #   #    #    # #####  #    #  ####  
; #    #  # #     ##  ## #    # ##   # #    # 
; #####    #      # ## # #####  # #  # #    # 
; #    #   #      #    # #    # #  # # #  # # 
; #    #   #      #    # #    # #   ## #   #  
; #####    #      #    # #####  #    #  ### # 
;
;
; 
; mbnq00@gmail.com
;
; .ini 	Version: 0.6.46
;  mod	Version: 0.6.46
;_____________________________________________________________________________________


RA2YRBF-MAP-PATCHER
	Simply drag and drop mapfile onto RA2YRBF_MAP_PATCHER2.exe to patch it.
	Patching adds spawning random crates for all players on their starting positions.

RA2YRBFMPCMD.exe
	Used by RA2YRBFMPALL.bat
	Doing same like above but not giving confirmation on job done
	
RA2YRBFMPALL.bat
	Put this with RA2YRBFMPCMD.exe in folder with your maps then run .bat script.
	It will patch every map in this folder.
