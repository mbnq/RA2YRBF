RA2YRBF-MAP-PATCHER
Simply drag and drop mapfile onto RA2YRBF_MAP_PATCHER2.exe to patch it.

Patching adds spawning random crates for all players on their starting positions.